"""Build an offline A/B/C replay with past-only score and event alignment."""
import argparse
import bisect
import csv
import json
import math
from pathlib import Path
import subprocess
import sys

import numpy as np
from PIL import Image, ImageDraw

from build_pre_z3_evidence import FPS, SIZE, font, load_segment, read, sha, text, write

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from research_tools.garment_trace_intake import verify_files

TITLES = {'A': '正常运行联调', 'B': '观测告警触发恢复', 'C': '缺检测条件时求助'}
COLORS = {'A': '#72D8CD', 'B': '#F1BA69', 'C': '#B7A7F6'}
OPERATIONS = dict(release='释放', retreat='退让', regrasp='重抓', close='闭手', lift='抬升')


def load(root, key):
    root = root.resolve()
    verify_files(root)
    trace = read(root / 'observation-trace.json')
    segment = load_segment(dict(source_directory=str(root), trial_id=trace['trial_id'],
                               sim_start_s=trace['observations'][0]['rendering_time_s']), key)
    events = [json.loads(line) for line in (root / 'pre-demo-events.jsonl').read_text(encoding='utf-8').splitlines()]
    assert all(event['trial_id'] == trace['trial_id'] for event in events)
    segment.update(events=events, speed=2. if key == 'A' else 1., hold=3. if key == 'B' else 2.5,
                   intro=1., start=5.950000310316682 if key == 'B' else segment['times'][0],
                   end=events[-1]['clock']['sim_time_s'])
    return segment


def available(segment, target):
    return [event for event in segment['events'] if event['clock']['sim_time_s'] <= target + 1e-9]


def detection_events(events):
    return [event for event in events if event['kind'] in
            ('OFFICIAL_DETECTION', 'PREFLIGHT_REDETECTION')]


def current_state(segment, target, events):
    if any(event['kind'] == 'HELP_REQUESTED' for event in events):
        return '求助 / 自动派发关闭'
    if segment['segment'] == 'B':
        for operation in segment['record'].get('macro_execution', []):
            if operation['begin']['sim_time_s'] <= target < operation['end']['sim_time_s']:
                return '恢复操作 · ' + OPERATIONS[operation['operation']]
        if any(event['kind'] == 'FIXED_CONTINUATION_ENABLED' for event in events):
            return '持有复检通过 / 接续'
        if any(event['kind'] == 'MACRO_RESULT' for event in events):
            return '恢复后连续持有检查'
        if any(event.get('request', {}).get('kind') == 'REQUEST_RECOVERY_PREFLIGHT'
               for event in detection_events(events) if event.get('request')):
            return '告警已确认 / 执行前检查'
    return '正常控制 / 观测检测'


def plot(draw, segment, events):
    x0, y0, width, height = 1032, 460, 514, 132
    draw.rectangle((x0, y0, x0 + width, y0 + height), fill='#172633', outline='#334B5D')
    reports = [event for event in detection_events(events) if event['report'].get('score') is not None]
    if not reports:
        text(draw, (x0 + 18, y0 + 42), '当前没有可用窗口分数', 23, '#B8C7D5')
        return
    ymin, ymax = .5, 1.5
    threshold = reports[-1]['report']['threshold']
    def position(event):
        t = event['clock']['sim_time_s']
        score = event['report']['score']
        return (x0 + (t - segment['start']) / (segment['end'] - segment['start']) * width,
                y0 + height - (score - ymin) / (ymax - ymin) * height)
    ty = y0 + height - (threshold - ymin) / (ymax - ymin) * height
    draw.line((x0, ty, x0 + width, ty), fill='#CBA3F3', width=2)
    text(draw, (x0 + 5, y0 + height + 4), f"{segment['start']:.2f}s", 17, '#A9B9C8')
    text(draw, (x0 + width - 68, y0 + height + 4), f"{segment['end']:.2f}s", 17, '#A9B9C8')
    previous = None
    for event in reports:
        point = position(event)
        if previous and event['clock']['sim_time_s'] - previous[0] <= .26:
            draw.line((*previous[1], *point), fill=COLORS[segment['segment']], width=3)
        color = '#FF8F8F' if event['report']['status'] == 'ANOMALY' else COLORS[segment['segment']]
        draw.ellipse((point[0]-3, point[1]-3, point[0]+3, point[1]+3), fill=color)
        previous = event['clock']['sim_time_s'], point


def render(segment, index, target, mode, caption=None):
    key = segment['segment']
    obs = segment['by_frame'][index]
    events = available(segment, target)
    detections = detection_events(events)
    latest = detections[-1] if detections else None
    im = Image.new('RGB', SIZE, '#101923')
    draw = ImageDraw.Draw(im)
    text(draw, (32, 19), '第三组 / FIPER RND-OE 观测分支适配', 23, '#A7B8C8')
    text(draw, (32, 54), key + '   ' + TITLES[key], 34, bold=True)
    text(draw, (1016, 24), '独立试次 / 离线回放', 26, COLORS[key])
    text(draw, (1016, 67), f'回放日志 {target:.3f} 仿真秒', 24)
    text(draw, (32, 103), f"全幅 RGB / 渲染 {obs['rendering_time_s']:.3f}s / 源帧 {index}", 18, '#B8C7D5')
    im.paste(Image.fromarray(segment['rgb'][index]).resize((960, 720), Image.Resampling.LANCZOS), (32, 128))
    label = {'intro': '片头静帧 1s', 'active': f"活动片段 {segment['speed']:g}× 仿真时间",
             'end': f"末帧停留 {segment['hold']:g}s / 最终日志", 'still': '静态备份 / 同试次记录'}[mode]
    text(draw, (1016, 131), label, 24, COLORS[key], bold=True)
    text(draw, (1016, 179), current_state(segment, target, events), 28, bold=True)
    if latest:
        report = latest['report']
        phase = latest.get('observation', {}).get('phase', 'HOLD')
        age = target-latest['clock']['sim_time_s']
        label = '历史检测  ' if age > .25 else '最近检测  '
        text(draw, (1016, 233), label + report['status'] + ' / ' + phase, 25, COLORS[key], bold=True)
        score = report.get('score')
        raw = report.get('raw_score')
        threshold = report.get('threshold')
        text(draw, (1016, 277), '窗口分数  ' + (f'{score:.6f}' if score is not None else '—'), 26)
        text(draw, (1016, 318), '原始分数  ' + (f'{raw:.6f}' if raw is not None else '—'), 24)
        text(draw, (1016, 358), '阈值  ' + (f'{threshold:.6f}' if threshold is not None else '—'), 24)
        text(draw, (1016, 404), f"检测日志 {latest['clock']['sim_time_s']:.3f}s / 距回放 {age:.3f}s", 19, '#A7B8C8')
    else:
        text(draw, (1016, 237), '等待首个检测报告', 25, '#B8C7D5')
    text(draw, (1032, 437), '五帧窗口分数 / 紫线为阈值', 16, '#A7B8C8')
    plot(draw, segment, events)
    if mode in ('end', 'still') and current_state(segment, target, events).startswith('求助'):
        note = {'A': '无注入试次出现非预期告警\n恢复 0 次 / 求助后新增派发 0\n误报性质待独立审核',
                'B': '恢复 1 次 / 五操作 75 条派发\n13 样本连续复检通过并接续\n再次告警后因预算耗尽求助',
                'C': '缺模型条件 / UNKNOWN 求助\n恢复 0 次 / 求助后新增派发 0\n产品停车验收待完成'}[key]
    elif key == 'B':
        checks = [event for event in events if event['kind'] == 'RECOVERY_CHECK']
        if checks:
            check = checks[-1]['report']
            note = f"几何复检 {check['status']} / {check.get('sample_count', 0)} 样本\n同一材料片与指尖世界坐标\n仿真内部几何来源"
        else:
            note = 'RGB 编码与五帧过去窗口\n执行前取得测量证据\n宏后采新观测检查持有'
    elif key == 'A':
        note = '无故障注入 / 持续检测\n计划释放保留阶段记录\n本轮为小规模开发验证'
    else:
        note = '检测包缺失时保留 UNKNOWN\n请求停止新增自动派发\n求助日志与最后 RGB 分别标时'
    text(draw, (1016, 640), note, 24, '#CFD9E2', width=548)
    if caption:
        text(draw, (1016, 783), caption, 20, '#FFFFFF', width=548)
    text(draw, (46, 857), f"试次 {segment['trial_id']} / 画面取自过去源帧 / 静帧停留单独标注", 20)
    return im, latest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('a', 'b', 'c', 'output', 'ffmpeg'):
        parser.add_argument('--' + key, type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    segments = [load(getattr(args, key.lower()), key) for key in 'ABC']
    video = out / 'Z3_ABC真实检测与恢复.mp4'
    if video.exists():
        raise FileExistsError('Preserve the previous video before generating a new version')
    command = [str(args.ffmpeg), '-hide_banner', '-loglevel', 'warning', '-n', '-f', 'rawvideo',
               '-pix_fmt', 'rgb24', '-s', '1600x900', '-r', str(FPS), '-i', '-', '-an',
               '-c:v', 'libx264', '-preset', 'fast', '-crf', '20', '-pix_fmt', 'yuv420p',
               '-movflags', '+faststart', str(video)]
    mapping, clips = [], []
    with (out / 'encode.log').open('wb') as log:
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stderr=log)
        try:
            for segment in segments:
                first = len(mapping)
                count = math.ceil((segment['end']-segment['start']) / segment['speed'] * FPS) + 1
                plan = [('intro', segment['start'])] * int(segment['intro'] * FPS)
                plan += [('active', min(segment['end'], segment['start']+i*segment['speed']/FPS)) for i in range(count)]
                plan += [('end', segment['end'])] * int(segment['hold'] * FPS)
                for mode, target in plan:
                    index = max(0, bisect.bisect_right(segment['times'], target)-1)
                    frame, latest = render(segment, index, target, mode)
                    process.stdin.write(frame.tobytes())
                    obs = segment['by_frame'][index]
                    mapping.append(dict(video_frame=len(mapping), video_time_s=len(mapping)/FPS,
                        segment=segment['segment'], trial_id=segment['trial_id'], mode=mode,
                        target_sim_s=target, source_frame_index=index, rendering_time_s=obs['rendering_time_s'],
                        observation_id=obs['observation_id'],
                        detection_observation_id=latest['report']['observation_id'] if latest else '',
                        detection_log_sim_s=latest['clock']['sim_time_s'] if latest else ''))
                clips.append(dict(segment=segment['segment'], trial_id=segment['trial_id'],
                    source_directory=str(segment['root']), video_start_s=first/FPS, video_end_s=len(mapping)/FPS,
                    first_video_frame=first, end_video_frame_exclusive=len(mapping), speed=segment['speed'],
                    intro_s=segment['intro'], hold_s=segment['hold'], sim_start_s=segment['start'],
                    sim_end_s=segment['end'], source_files=segment['source_files']))
                print('Rendered', segment['segment'], len(mapping), flush=True)
        finally:
            process.stdin.close()
        if process.wait() != 0:
            raise RuntimeError('Video encoding failed')
    with (out / 'video-frame-map.csv').open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(mapping[0]))
        writer.writeheader()
        writer.writerows(mapping)
    selections = [('A', 6.3, '01_A正常提起'), ('A', 7.4, '02_A计划释放'),
                  ('A', segments[0]['end'], '03_A非预期告警求助'),
                  ('B', 7.5, '04_B观测告警'), ('B', 9.4, '05_B五操作执行'),
                  ('B', 11.116667246446013, '06_B持续复检与接续'),
                  ('B', segments[1]['end'], '07_B再次告警求助'),
                  ('C', segments[2]['end'], '08_C缺条件求助')]
    index_entries = []
    shots = out / '关键截图'
    originals = shots / '原始对应帧'
    originals.mkdir(parents=True, exist_ok=True)
    for key, target, name in selections:
        segment = next(s for s in segments if s['segment'] == key)
        index = max(0, bisect.bisect_right(segment['times'], target)-1)
        raw, annotated = originals / (name+'.png'), shots / (name+'.png')
        Image.fromarray(segment['rgb'][index]).save(raw)
        frame, latest = render(segment, index, target, 'still')
        frame.save(annotated)
        obs = segment['by_frame'][index]
        index_entries.append(dict(file=annotated.relative_to(out).as_posix(),
            raw_file=raw.relative_to(out).as_posix(), trial_id=segment['trial_id'],
            source_frame_index=index, observation_id=obs['observation_id'],
            rendering_time_s=obs['rendering_time_s'], replay_log_sim_s=target,
            raw_sha256=sha(raw), annotated_sha256=sha(annotated)))
    write(out / '截图索引.json', index_entries)
    write(out / 'replay-events.json', [dict(segment=s['segment'], trial_id=s['trial_id'],
        events=s['events'], macro_execution=s['record'].get('macro_execution', [])) for s in segments])
    write(out / 'manifest.json', dict(schema='z3-actual-abc/1',
        video=dict(file=video.name, frames=len(mapping), fps=FPS, duration_s=len(mapping)/FPS,
                   dimensions=list(SIZE), audio=False, bytes=video.stat().st_size, sha256=sha(video)),
        clips=clips, generator_sha256=sha(__file__), shared_renderer_sha256=sha(Path(__file__).with_name('build_pre_z3_evidence.py')),
        score_alignment='Only reports whose logged simulation time is no later than replay time',
        source_frame_alignment='Latest original RGB no later than replay time',
        source_arrays_modified=False, image_transform='Full 640x480 RGB scaled to 960x720',
        experimental_independent_review='pending'))
    for filename in ('build_pre_abc_evidence.py', 'build_pre_z3_evidence.py'):
        (out / filename).write_bytes(Path(__file__).with_name(filename).read_bytes())
    print(json.dumps(dict(video=str(video), frames=len(mapping), duration_s=len(mapping)/FPS)))


if __name__ == '__main__':
    main()
